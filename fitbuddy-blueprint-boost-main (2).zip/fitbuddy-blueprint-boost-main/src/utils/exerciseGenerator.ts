
import { ExerciseRoutine, UserData } from "@/types/user";
import { yogaRoutines, strengthTraining } from "./exerciseData";

export const generateExerciseRoutine = (userData: UserData): ExerciseRoutine => {
  const { goal } = userData;
  let level = "intermediate";
  
  const yogaProgram = yogaRoutines[level];
  const strengthProgram = strengthTraining[level];
  
  switch(goal) {
    case "lose":
      return {
        warmup: [
          ...strengthProgram.warmup,
          "Cardiovascular warm-up - 8 minutes",
        ],
        workout: [
          "Circuit Training:",
          ...strengthProgram.exercises.map(ex => `${ex} [Higher reps, lower weight]`),
          "\nYoga Flow:",
          ...yogaProgram.poses.slice(0, 3)
        ],
        cooldown: [
          ...yogaProgram.cooldown,
          ...strengthProgram.cooldown
        ]
      };
    case "gain":
      return {
        warmup: [
          ...strengthProgram.warmup,
          "Joint mobility exercises",
        ],
        workout: [
          "Strength Focus:",
          ...strengthProgram.exercises.map(ex => `${ex} [Progressive overload focus]`),
          "\nMobility Work:",
          ...yogaProgram.poses.slice(0, 2)
        ],
        cooldown: [
          ...strengthProgram.cooldown,
          "Progressive muscle relaxation"
        ]
      };
    default:
      return {
        warmup: [
          ...yogaProgram.warmup,
          ...strengthProgram.warmup.slice(0, 2),
          "Dynamic mobility exercises - 5 minutes"
        ],
        workout: [
          "Balanced Fitness Routine:",
          ...strengthProgram.exercises.slice(0, 3),
          "\nYoga and Flexibility:",
          ...yogaProgram.poses,
          "Core stability exercises - 10 minutes"
        ],
        cooldown: [
          ...yogaProgram.cooldown,
          "Stretching and relaxation - 10 minutes",
          "Deep breathing and mindfulness"
        ]
      };
  }
};
