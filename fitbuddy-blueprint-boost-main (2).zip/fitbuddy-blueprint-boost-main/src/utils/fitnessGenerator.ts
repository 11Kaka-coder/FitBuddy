
import { FitnessPlan, UserData } from "@/types/user";
import { calculateBMI, getBMICategory } from "./bmiCalculator";
import { generateMealPlan } from "./mealPlanGenerator";
import { generateExerciseRoutine } from "./exerciseGenerator";

export const generateFitnessPlan = (userData: UserData): FitnessPlan => {
  const estimatedHeightCm = parseInt(userData.gender) === 1 ? 170 : 160;
  const weightKg = parseFloat(userData.weight);
  const bmi = calculateBMI(weightKg, estimatedHeightCm);
  const bmiCategory = getBMICategory(bmi);
  
  const mealPlan = generateMealPlan(userData);
  const exerciseRoutine = generateExerciseRoutine(userData);
  
  return {
    meals: mealPlan,
    exercises: exerciseRoutine,
    bmi,
    bmiCategory
  };
};
