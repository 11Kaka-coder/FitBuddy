
import { MealPlan, UserData } from "@/types/user";

const vegetarianMeals = {
  breakfast: [
    "Overnight oats with almond milk, chia seeds, and mixed berries (320 cal, 14g protein)",
    "Tofu scramble with spinach and whole grain toast (350 cal, 18g protein)",
    "Protein smoothie bowl with plant-based protein, banana, and granola (300 cal, 16g protein)"
  ],
  lunch: [
    "Quinoa Buddha bowl with roasted chickpeas and tahini dressing (420 cal, 18g protein)",
    "Lentil and sweet potato curry with brown rice (450 cal, 20g protein)",
    "Mediterranean chickpea salad with olive oil dressing (380 cal, 15g protein)"
  ],
  dinner: [
    "Grilled tempeh steak with roasted vegetables (480 cal, 24g protein)",
    "Black bean and quinoa enchiladas (460 cal, 22g protein)",
    "Stir-fried tofu with brown rice and broccoli (420 cal, 20g protein)"
  ],
  snacks: [
    "Mixed nuts and dried fruits (200 cal, 8g protein)",
    "Hummus with vegetable crudités (150 cal, 6g protein)",
    "Plant-based protein bar (180 cal, 15g protein)"
  ]
};

const nonVegetarianMeals = {
  breakfast: [
    "Greek yogurt protein bowl with mixed berries and honey (300 cal, 20g protein)",
    "Turkey and egg white omelet with whole grain toast (350 cal, 28g protein)",
    "Protein pancakes with whey protein and banana (320 cal, 25g protein)"
  ],
  lunch: [
    "Grilled chicken breast with quinoa and roasted vegetables (450 cal, 35g protein)",
    "Salmon poke bowl with brown rice and avocado (480 cal, 32g protein)",
    "Lean turkey wrap with mixed greens and hummus (400 cal, 30g protein)"
  ],
  dinner: [
    "Baked cod with sweet potato mash and asparagus (420 cal, 35g protein)",
    "Lean beef stir-fry with brown rice and broccoli (480 cal, 38g protein)",
    "Grilled chicken with zucchini noodles (400 cal, 36g protein)"
  ],
  snacks: [
    "Protein shake with almond milk (160 cal, 20g protein)",
    "Hard-boiled eggs with cherry tomatoes (140 cal, 13g protein)",
    "Greek yogurt with honey (130 cal, 12g protein)"
  ]
};

export const generateMealPlan = (userData: UserData): MealPlan => {
  const { goal, dietaryPreference } = userData;
  const meals = dietaryPreference === 'vegetarian' ? vegetarianMeals : nonVegetarianMeals;
  
  if (goal === 'lose') {
    return {
      breakfast: meals.breakfast.map(meal => `${meal} [Reduced portion]`),
      lunch: meals.lunch.map(meal => `${meal} [Reduced portion]`),
      dinner: meals.dinner.map(meal => `${meal} [Reduced portion]`),
      snacks: meals.snacks.slice(0, 2)
    };
  }
  
  if (goal === 'gain') {
    return {
      breakfast: meals.breakfast.map(meal => `${meal} [Increased portion]`),
      lunch: meals.lunch.map(meal => `${meal} [Increased portion + healthy fats]`),
      dinner: meals.dinner.map(meal => `${meal} [Increased portion + extra protein]`),
      snacks: [...meals.snacks, "Additional protein shake (200 cal, 25g protein)"]
    };
  }

  return {
    breakfast: meals.breakfast.map(meal => `${meal} [Balanced Portion]`),
    lunch: meals.lunch.map(meal => `${meal} [Maintenance Calories]`),
    dinner: meals.dinner.map(meal => `${meal} [Balanced Macronutrients]`),
    snacks: meals.snacks
  };
};
