export const yogaRoutines = {
  beginner: {
    warmup: [
      "Sun Salutation A (Surya Namaskar A) - 5 gentle rounds",
      "Cat-Cow Pose (Marjaryasana-Bitilasana) - 2 minutes",
      "Child's Pose (Balasana) - 1 minute"
    ],
    poses: [
      "Mountain Pose (Tadasana) - 30 seconds",
      "Tree Pose (Vrksasana) - 30 seconds each side",
      "Warrior I (Virabhadrasana I) - 30 seconds each side",
      "Triangle Pose (Trikonasana) - 30 seconds each side",
      "Cobra Pose (Bhujangasana) - 30 seconds"
    ],
    cooldown: [
      "Seated Forward Bend (Paschimottanasana) - 1 minute",
      "Corpse Pose (Savasana) - 5 minutes",
      "Deep breathing exercises"
    ]
  },
  intermediate: {
    warmup: [
      "Sun Salutation B (Surya Namaskar B) - 5 rounds",
      "Dynamic stretching sequence",
      "Standing twists and side bends"
    ],
    poses: [
      "Warrior II & III (Virabhadrasana II & III) - 45 seconds each",
      "Half Moon Pose (Ardha Chandrasana) - 30 seconds each side",
      "Crow Pose (Bakasana) - 3 attempts, hold for 20 seconds",
      "Bridge Pose (Setu Bandha Sarvangasana) - 1 minute",
      "Pigeon Pose (Eka Pada Rajakapotasana) - 1 minute each side"
    ],
    cooldown: [
      "Seated twists - 30 seconds each side",
      "Shoulder stand (Sarvangasana) - 2 minutes",
      "Final relaxation - 5 minutes"
    ]
  },
  advanced: {
    warmup: [
      "Sun Salutation C - 5 rounds with jumps",
      "Dynamic flexibility work",
      "Core activation sequence"
    ],
    poses: [
      "Handstand practice (Adho Mukha Vrksasana) - 5 minutes",
      "Forearm Stand (Pincha Mayurasana) - 3 minutes",
      "Eight-Angle Pose (Astavakrasana) - 30 seconds each side",
      "King Pigeon Pose (Raja Kapotasana) - 1 minute each side",
      "Firefly Pose (Tittibhasana) - 3 attempts"
    ],
    cooldown: [
      "Wheel Pose (Urdhva Dhanurasana) - 3 sets",
      "Headstand (Sirsasana) - 5 minutes",
      "Meditation - 10 minutes"
    ]
  }
};

export const strengthTraining = {
  beginner: {
    warmup: [
      "Light cardio - 5 minutes",
      "Dynamic stretching - 3 minutes",
      "Bodyweight squats - 10 reps"
    ],
    exercises: [
      "Push-ups (modified if needed) - 3 sets of 8-10",
      "Bodyweight squats - 3 sets of 12-15",
      "Dumbbell rows - 3 sets of 10 each side",
      "Glute bridges - 3 sets of 15",
      "Plank hold - 3 sets of 20-30 seconds"
    ],
    cooldown: [
      "Walking - 5 minutes",
      "Static stretching - 5 minutes",
      "Deep breathing"
    ]
  },
  intermediate: {
    warmup: [
      "Jump rope - 5 minutes",
      "Dynamic stretching - 5 minutes",
      "Mobility work - 3 minutes"
    ],
    exercises: [
      "Push-ups - 4 sets of 12-15",
      "Bulgarian split squats - 3 sets of 12 each leg",
      "Dumbbell bench press - 4 sets of 10-12",
      "Romanian deadlifts - 3 sets of 12",
      "Core circuit - 3 rounds"
    ],
    cooldown: [
      "Light cardio - 5 minutes",
      "Mobility work - 5 minutes",
      "Stretching - 5 minutes"
    ]
  },
  advanced: {
    warmup: [
      "High-intensity intervals - 8 minutes",
      "Dynamic stretching - 5 minutes",
      "Activation exercises - 5 minutes"
    ],
    exercises: [
      "Weighted pull-ups - 4 sets of 8-10",
      "Barbell squats - 5 sets of 5",
      "Bench press - 5 sets of 5",
      "Deadlifts - 4 sets of 6",
      "Olympic lifting technique work"
    ],
    cooldown: [
      "Mobility work - 8 minutes",
      "Static stretching - 7 minutes",
      "Recovery techniques"
    ]
  }
};
