import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { UserData } from "@/types/user";
import { z } from "zod";
import { Card } from "./ui/card";
import { UserRound } from "lucide-react";

const formSchema = z.object({
  age: z.string().min(1, "Age is required"),
  weight: z.string().min(1, "Weight is required"),
  gender: z.string(),
  goal: z.string(),
  dietaryPreference: z.string()
});

interface UserFormProps {
  onSubmit: (data: UserData) => void;
}

const UserForm = ({ onSubmit }: UserFormProps) => {
  const form = useForm<UserData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: "",
      weight: "",
      gender: "male",
      goal: "lose",
      dietaryPreference: "non-vegetarian"
    }
  });

  return (
    <Card className="p-8 shadow-lg bg-card hover:shadow-xl transition-all duration-300 border-2">
      <div className="flex items-center justify-center mb-6">
        <div className="bg-fitbuddy-purple/10 p-3 rounded-full">
          <UserRound className="h-8 w-8 text-fitbuddy-purple" />
        </div>
      </div>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="age"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-base">Age</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter your age" 
                      {...field}
                      className="transition-all duration-200 hover:border-fitbuddy-purple focus:border-fitbuddy-purple"
                    />
                  </FormControl>
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="weight"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-base">Weight (kg)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Enter your weight" 
                      {...field}
                      className="transition-all duration-200 hover:border-fitbuddy-purple focus:border-fitbuddy-purple"
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="gender"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-base">Gender</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-1 md:grid-cols-3 gap-4"
                  >
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-3 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="male" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Male</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-3 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="female" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Female</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-3 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="other" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Other</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="goal"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-base">Goal</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-1 md:grid-cols-3 gap-4"
                  >
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-4 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="lose" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Lose Weight</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-4 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="gain" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Gain Weight</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-4 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="stay" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Stay Fit</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="dietaryPreference"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-base">Dietary Preference</FormLabel>
                <FormControl>
                  <RadioGroup
                    onValueChange={field.onChange}
                    defaultValue={field.value}
                    className="grid grid-cols-1 md:grid-cols-2 gap-4"
                  >
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-4 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="vegetarian" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Vegetarian</FormLabel>
                    </FormItem>
                    <FormItem className="flex items-center space-x-2 bg-card hover:bg-accent p-4 rounded-lg cursor-pointer transition-colors">
                      <FormControl>
                        <RadioGroupItem value="non-vegetarian" />
                      </FormControl>
                      <FormLabel className="font-normal cursor-pointer">Non-Vegetarian</FormLabel>
                    </FormItem>
                  </RadioGroup>
                </FormControl>
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full bg-fitbuddy-purple hover:bg-fitbuddy-purple/90 text-white font-semibold py-6">
            Generate Plan
          </Button>
        </form>
      </Form>
    </Card>
  );
};

export default UserForm;
