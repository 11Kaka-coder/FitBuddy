
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ExerciseRoutine } from "@/types/user";
import { Timer, Dumbbell, Heart, Activity } from "lucide-react";

interface ExerciseRoutineDisplayProps {
  exerciseRoutine: ExerciseRoutine;
}

const ExerciseRoutineDisplay = ({ exerciseRoutine }: ExerciseRoutineDisplayProps) => {
  const { workout } = exerciseRoutine;
  const yogaIndex = workout.findIndex(item => item.includes("Yoga"));
  const strengthSection = workout.slice(0, yogaIndex);
  const yogaSection = workout.slice(yogaIndex);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-medium">
            <div className="flex items-center">
              <Timer className="mr-2 h-5 w-5 text-fitbuddy-purple" />
              Warm-up (10-15 minutes)
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {exerciseRoutine.warmup.map((item, index) => (
              <li key={index} className="flex items-start">
                <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-gradient-to-br from-purple-50 to-transparent dark:from-purple-900/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <Dumbbell className="mr-2 h-5 w-5 text-fitbuddy-purple" />
                Strength Training
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {strengthSection.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-transparent dark:from-blue-900/10">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <Activity className="mr-2 h-5 w-5 text-fitbuddy-teal" />
                Yoga Flow
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {yogaSection.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-teal">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-lg font-medium">
            <div className="flex items-center">
              <Heart className="mr-2 h-5 w-5 text-fitbuddy-purple" />
              Cool-down (5-10 minutes)
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {exerciseRoutine.cooldown.map((item, index) => (
              <li key={index} className="flex items-start">
                <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
      
      <div className="p-4 bg-muted/50 rounded-lg text-center">
        <p className="text-muted-foreground text-sm">Advertisement Space</p>
      </div>
    </div>
  );
};

export default ExerciseRoutineDisplay;
