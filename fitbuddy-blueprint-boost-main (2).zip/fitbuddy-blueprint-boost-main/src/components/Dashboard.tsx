import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FitnessPlan, UserData } from "@/types/user";
import MealPlanDisplay from "./MealPlanDisplay";
import ExerciseRoutineDisplay from "./ExerciseRoutineDisplay";
import ProgressTracker from "./ProgressTracker";
import { toast } from "@/components/ui/sonner";
import { generateFitnessPlan } from "@/utils/fitnessGenerator";
import AdPlaceholder from "./AdPlaceholder";

interface DashboardProps {
  userData: UserData;
  onReset: () => void;
}

const Dashboard = ({ userData, onReset }: DashboardProps) => {
  const [fitnessPlan, setFitnessPlan] = useState<FitnessPlan | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    try {
      const plan = generateFitnessPlan(userData);
      setFitnessPlan(plan);
      toast.success("Your personalized fitness plan is ready!");
    } catch (error) {
      console.error("Error generating fitness plan:", error);
      toast.error("Failed to generate your fitness plan. Please try again.");
    } finally {
      setLoading(false);
    }
  }, [userData]);

  const getBmiColor = (bmi: number): string => {
    if (bmi < 18.5) return "text-blue-500";
    if (bmi < 25) return "text-green-500";
    if (bmi < 30) return "text-yellow-500";
    return "text-red-500";
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-center">
          <p className="text-lg font-medium">Generating your personalized plan...</p>
        </div>
      </div>
    );
  }

  if (!fitnessPlan) {
    return (
      <div className="text-center">
        <p>Something went wrong. Please try again.</p>
        <button 
          onClick={onReset} 
          className="mt-4 px-4 py-2 bg-fitbuddy-purple text-white rounded-md"
        >
          Start Over
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 animate-fade-in">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-fitbuddy-purple">Your FitBuddy Plan</h1>
          <p className="text-gray-600">
            Personalized for your {userData.goal === "lose" ? "weight loss" : 
              userData.goal === "gain" ? "weight gain" : "weight maintenance"} goal
          </p>
        </div>
        <button 
          onClick={onReset} 
          className="mt-4 md:mt-0 px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-md transition-colors"
        >
          Start Over
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Your BMI</CardTitle>
          </CardHeader>
          <CardContent>
            <p className={`text-3xl font-bold ${getBmiColor(fitnessPlan.bmi)}`}>
              {fitnessPlan.bmi}
            </p>
            <p className="text-sm text-gray-500">{fitnessPlan.bmiCategory}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Age</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{userData.age}</p>
            <p className="text-sm text-gray-500">Years</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Current Weight</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{userData.weight}</p>
            <p className="text-sm text-gray-500">Kilograms</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="meals" className="w-full">
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="meals">Meal Plan</TabsTrigger>
          <TabsTrigger value="exercise">Exercise Routine</TabsTrigger>
          <TabsTrigger value="progress">Progress Tracker</TabsTrigger>
        </TabsList>
        
        <TabsContent value="meals" className="mt-0">
          <MealPlanDisplay mealPlan={fitnessPlan.meals} />
        </TabsContent>
        
        <TabsContent value="exercise" className="mt-0">
          <ExerciseRoutineDisplay exerciseRoutine={fitnessPlan.exercises} />
        </TabsContent>
        
        <TabsContent value="progress" className="mt-0">
          <ProgressTracker userData={userData} />
        </TabsContent>
      </Tabs>

      <div className="mt-8">
        <AdPlaceholder type="banner" />
      </div>
    </div>
  );
};

export default Dashboard;
