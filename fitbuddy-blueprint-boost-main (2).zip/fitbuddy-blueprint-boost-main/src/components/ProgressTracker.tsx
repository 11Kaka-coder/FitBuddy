import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserData } from "@/types/user";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

interface ProgressTrackerProps {
  userData: UserData;
}

const ProgressTracker = ({ userData }: ProgressTrackerProps) => {
  const [weight, setWeight] = useState(userData.weight);
  const [progressData, setProgressData] = useState([
    {
      day: "Day 1",
      weight: parseFloat(userData.weight),
    },
  ]);

  const handleAddWeight = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newEntry = {
      day: `Day ${progressData.length + 1}`,
      weight: parseFloat(weight),
    };
    
    setProgressData([...progressData, newEntry]);
  };

  const getWeightChange = () => {
    if (progressData.length <= 1) return 0;
    const initialWeight = progressData[0].weight;
    const currentWeight = progressData[progressData.length - 1].weight;
    return currentWeight - initialWeight;
  };

  const weightChange = getWeightChange();
  const weightGoal = userData.goal;

  const isPositiveChange = 
    (weightGoal === "gain" && weightChange > 0) || 
    (weightGoal === "lose" && weightChange < 0);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Weekly Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis domain={['auto', 'auto']} />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="weight" 
                  stroke="#8B5CF6" 
                  strokeWidth={2} 
                  dot={{ fill: "#8B5CF6" }} 
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Log Today's Weight</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleAddWeight} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="current-weight">Current Weight (kg)</Label>
              <Input
                id="current-weight"
                type="number"
                value={weight}
                onChange={(e) => setWeight(e.target.value)}
                min="30"
                max="300"
                step="0.1"
                required
              />
            </div>
            <Button 
              type="submit" 
              className="w-full bg-fitbuddy-purple hover:bg-purple-700 transition-colors"
            >
              Log Weight
            </Button>
          </form>
        </CardContent>
      </Card>

      {progressData.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle>Weight Change Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Starting Weight:</span>
                <span className="font-semibold">{progressData[0].weight} kg</span>
              </div>
              <div className="flex justify-between">
                <span>Current Weight:</span>
                <span className="font-semibold">{progressData[progressData.length - 1].weight} kg</span>
              </div>
              <div className="flex justify-between">
                <span>Change:</span>
                <span className={`font-semibold ${isPositiveChange ? 'text-green-500' : 'text-red-500'}`}>
                  {weightChange > 0 ? "+" : ""}{weightChange.toFixed(1)} kg
                </span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <span className={`font-semibold ${isPositiveChange ? 'text-green-500' : 'text-red-500'}`}>
                  {isPositiveChange ? "On Track" : "Not Aligned with Goal"}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ProgressTracker;
