
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MealPlan } from "@/types/user";
import { Fish, Beef, Carrot, Apple, Utensils, List } from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface MealPlanDisplayProps {
  mealPlan: MealPlan;
}

const MealPlanDisplay = ({ mealPlan }: MealPlanDisplayProps) => {
  // Calculate proportions for the pie chart
  const data = [
    { name: 'Proteins', value: 30 },
    { name: 'Carbs', value: 40 },
    { name: 'Fats', value: 30 },
  ];

  const COLORS = ['#8B5CF6', '#0EA5E9', '#F97316'];

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="col-span-1 md:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg font-medium">Daily Nutrient Distribution</CardTitle>
          </CardHeader>
          <CardContent className="flex justify-center items-center h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <Apple className="mr-2 h-5 w-5 text-fitbuddy-purple" />
                Breakfast
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {mealPlan.breakfast.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <Utensils className="mr-2 h-5 w-5 text-fitbuddy-purple" />
                Lunch
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {mealPlan.lunch.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <List className="mr-2 h-5 w-5 text-fitbuddy-purple" />
                Dinner
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {mealPlan.dinner.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-medium">
              <div className="flex items-center">
                <Apple className="mr-2 h-5 w-5 text-fitbuddy-purple" />
                Snacks
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {mealPlan.snacks.map((item, index) => (
                <li key={index} className="flex items-start">
                  <div className="mr-2 h-5 w-5 text-fitbuddy-purple">•</div>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MealPlanDisplay;
