
import { Card } from "./ui/card";

interface AdPlaceholderProps {
  type?: "banner" | "sidebar" | "inline";
}

const AdPlaceholder = ({ type = "banner" }: AdPlaceholderProps) => {
  const dimensions = {
    banner: "h-[90px] w-full",
    sidebar: "h-[600px] w-[300px]",
    inline: "h-[250px] w-full"
  };

  return (
    <Card className={`${dimensions[type]} flex items-center justify-center bg-muted/50 my-4`}>
      <p className="text-muted-foreground text-sm">Advertisement Space</p>
    </Card>
  );
};

export default AdPlaceholder;
