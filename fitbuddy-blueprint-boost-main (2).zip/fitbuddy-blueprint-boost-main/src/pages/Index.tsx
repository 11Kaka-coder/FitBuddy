
import { useState } from "react";
import { UserData } from "@/types/user";
import UserForm from "@/components/UserForm";
import Dashboard from "@/components/Dashboard";
import { Toaster } from "@/components/ui/sonner";
import Navbar from "@/components/Navbar";
import AdPlaceholder from "@/components/AdPlaceholder";

const Index = () => {
  const [userData, setUserData] = useState<UserData | null>(null);

  const handleFormSubmit = (data: UserData) => {
    setUserData(data);
  };

  const handleReset = () => {
    setUserData(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-purple-50/50 to-background dark:from-gray-900 dark:via-purple-900/10 dark:to-gray-900">
      <Navbar />
      
      <main className="container mx-auto px-4 pt-20 pb-8">
        {userData ? (
          <>
            <Dashboard userData={userData} onReset={handleReset} />
            <AdPlaceholder type="banner" />
          </>
        ) : (
          <div className="max-w-4xl mx-auto pt-12 pb-8 animate-fade-in">
            <div className="text-center mb-12">
              <h1 className="text-5xl font-bold bg-gradient-to-r from-fitbuddy-purple to-fitbuddy-teal bg-clip-text text-transparent mb-6">
                Welcome to FitBuddy
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
                Your personal fitness companion. Generate a customized diet and exercise plan based on your goals and profile.
              </p>
            </div>
            <UserForm onSubmit={handleFormSubmit} />
            
            <div className="mt-12 space-y-6">
              <section className="text-center p-8 bg-card rounded-lg border-2 animate-fade-in">
                <h2 className="text-2xl font-semibold mb-4 bg-gradient-to-r from-fitbuddy-purple to-fitbuddy-teal bg-clip-text text-transparent">
                  Why Choose FitBuddy?
                </h2>
                <div className="grid md:grid-cols-3 gap-6 mt-8">
                  <div className="p-4">
                    <h3 className="text-lg font-semibold mb-2">Personalized Plans</h3>
                    <p className="text-muted-foreground">Customized diet and exercise routines tailored to your goals</p>
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-semibold mb-2">Progress Tracking</h3>
                    <p className="text-muted-foreground">Monitor your fitness journey with detailed analytics</p>
                  </div>
                  <div className="p-4">
                    <h3 className="text-lg font-semibold mb-2">Expert Guidance</h3>
                    <p className="text-muted-foreground">Science-based recommendations for optimal results</p>
                  </div>
                </div>
              </section>

              <AdPlaceholder type="banner" />
            </div>
          </div>
        )}
      </main>
      <Toaster />
    </div>
  );
};

export default Index;
