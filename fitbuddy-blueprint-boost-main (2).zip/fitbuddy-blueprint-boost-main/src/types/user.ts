
export interface UserData {
  age: string;
  weight: string;
  gender: "male" | "female" | "other";
  goal: "lose" | "gain" | "stay";
  dietaryPreference: "vegetarian" | "non-vegetarian";
}

export interface MealPlan {
  breakfast: string[];
  lunch: string[];
  dinner: string[];
  snacks: string[];
}

export interface ExerciseRoutine {
  warmup: string[];
  workout: string[];
  cooldown: string[];
}

export interface FitnessPlan {
  meals: MealPlan;
  exercises: ExerciseRoutine;
  bmi: number;
  bmiCategory: string;
}
