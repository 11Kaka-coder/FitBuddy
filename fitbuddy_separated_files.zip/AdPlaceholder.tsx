
import { Card } from "@/components/ui/card";

interface AdPlaceholderProps {
  position: "top" | "sidebar" | "footer";
}

const AdPlaceholder = ({ position }: AdPlaceholderProps) => {
  const getDimensions = () => {
    switch (position) {
      case "top":
        return "h-24 w-full";
      case "sidebar":
        return "h-[600px] w-full";
      case "footer":
        return "h-32 w-full";
      default:
        return "h-24 w-full";
    }
  };
  
  const dimensions = getDimensions();

  return (
    <Card className={`ad-placeholder ${dimensions} flex items-center justify-center bg-gradient-to-br from-gray-100/50 to-white/50 dark:from-gray-800/50 dark:to-gray-900/50 backdrop-blur-sm border-2 border-gray-200/50 dark:border-gray-700/50`}>
      <p className="text-gray-500 dark:text-gray-400 text-sm font-medium">
        Advertisement ({position})
      </p>
    </Card>
  );
};

export default AdPlaceholder;
