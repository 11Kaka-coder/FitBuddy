
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface HealthMetricsProps {
  bmi: number;
  bmiCategory: string;
  bmr: number;
  dailyCalories: number;
}

const HealthMetrics = ({ bmi, bmiCategory, bmr, dailyCalories }: HealthMetricsProps) => {
  // Function to get the color based on BMI category
  const getBmiColor = (category: string) => {
    switch (category) {
      case "Underweight":
        return "text-yellow-500";
      case "Normal weight":
        return "text-green-500";
      case "Overweight":
        return "text-yellow-500";
      case "Obesity class I":
      case "Obesity class II":
      case "Obesity class III":
        return "text-red-500";
      default:
        return "text-gray-700";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      <Card className="results-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            BMI & Body Composition
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <span className="text-gray-600 dark:text-gray-400">Body Mass Index (BMI):</span>
              <p className="metric-value">{bmi}</p>
            </div>
            <div>
              <span className="text-gray-600 dark:text-gray-400">Category:</span>
              <p className={`text-lg font-medium ${getBmiColor(bmiCategory)}`}>
                {bmiCategory}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="results-card">
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            Metabolic Rate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <span className="text-gray-600 dark:text-gray-400">Basal Metabolic Rate (BMR):</span>
              <p className="metric-value">{bmr} calories/day</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Calories needed at complete rest
              </p>
            </div>
            <div>
              <span className="text-gray-600 dark:text-gray-400">Daily Calorie Needs:</span>
              <p className="metric-value">{dailyCalories} calories/day</p>
              <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                Adjusted for your activity level and goal
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default HealthMetrics;
