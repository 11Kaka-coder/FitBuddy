
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";

interface UserFormData {
  age: string;
  gender: string;
  height: string;
  weight: string;
  activityLevel: string;
  bodyType: string;
  dietType: string;
  fitnessGoal: string;
}

interface UserInputFormProps {
  onSubmit: (data: UserFormData) => void;
}

const UserInputForm = ({ onSubmit }: UserInputFormProps) => {
  const [formData, setFormData] = useState<UserFormData>({
    age: "",
    gender: "",
    height: "",
    weight: "",
    activityLevel: "",
    bodyType: "",
    dietType: "",
    fitnessGoal: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData({ ...formData, [name]: value });
  };

  const validateForm = () => {
    const { age, gender, height, weight, activityLevel, bodyType, dietType, fitnessGoal } = formData;
    
    if (!age || parseInt(age) < 12 || parseInt(age) > 100) {
      toast.error("Please enter a valid age between 12 and 100");
      return false;
    }
    
    if (!gender) {
      toast.error("Please select your gender");
      return false;
    }
    
    if (!height || parseFloat(height) < 100 || parseFloat(height) > 250) {
      toast.error("Please enter a valid height in cm (100-250)");
      return false;
    }
    
    if (!weight || parseFloat(weight) < 30 || parseFloat(weight) > 250) {
      toast.error("Please enter a valid weight in kg (30-250)");
      return false;
    }
    
    if (!activityLevel || !bodyType || !dietType || !fitnessGoal) {
      toast.error("Please complete all fields");
      return false;
    }
    
    return true;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto mb-8 border border-gray-200 dark:border-gray-800">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">Enter Your Details</CardTitle>
        <CardDescription className="text-center">
          We'll use this information to calculate your fitness metrics and create a personalized plan
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="input-group">
              <Label htmlFor="age">Age (years)</Label>
              <Input
                id="age"
                name="age"
                type="number"
                placeholder="Enter your age"
                value={formData.age}
                onChange={handleChange}
                required
                min="12"
                max="100"
              />
            </div>
            
            <div className="input-group">
              <Label htmlFor="gender">Gender</Label>
              <Select
                onValueChange={(value) => handleSelectChange("gender", value)}
                value={formData.gender}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select gender" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">Male</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="input-group">
              <Label htmlFor="height">Height (cm)</Label>
              <Input
                id="height"
                name="height"
                type="number"
                placeholder="Enter height in cm"
                value={formData.height}
                onChange={handleChange}
                required
                min="100"
                max="250"
                step="0.1"
              />
            </div>
            
            <div className="input-group">
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input
                id="weight"
                name="weight"
                type="number"
                placeholder="Enter weight in kg"
                value={formData.weight}
                onChange={handleChange}
                required
                min="30"
                max="250"
                step="0.1"
              />
            </div>
            
            <div className="input-group">
              <Label htmlFor="activityLevel">Activity Level</Label>
              <Select
                onValueChange={(value) => handleSelectChange("activityLevel", value)}
                value={formData.activityLevel}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select activity level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="sedentary">Sedentary (little or no exercise)</SelectItem>
                  <SelectItem value="light">Light (exercise 1-3 times/week)</SelectItem>
                  <SelectItem value="moderate">Moderate (exercise 3-5 times/week)</SelectItem>
                  <SelectItem value="active">Active (exercise 6-7 times/week)</SelectItem>
                  <SelectItem value="veryActive">Very Active (intense exercise daily)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="input-group">
              <Label htmlFor="bodyType">Body Type</Label>
              <Select
                onValueChange={(value) => handleSelectChange("bodyType", value)}
                value={formData.bodyType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select body type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ectomorph">Ectomorph (thin, lean build)</SelectItem>
                  <SelectItem value="mesomorph">Mesomorph (muscular, athletic build)</SelectItem>
                  <SelectItem value="endomorph">Endomorph (higher body fat, stocky build)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="input-group">
              <Label htmlFor="dietType">Diet Type</Label>
              <Select
                onValueChange={(value) => handleSelectChange("dietType", value)}
                value={formData.dietType}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select diet type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vegetarian">Vegetarian</SelectItem>
                  <SelectItem value="nonVegetarian">Non-Vegetarian</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="input-group">
              <Label htmlFor="fitnessGoal">Fitness Goal</Label>
              <Select
                onValueChange={(value) => handleSelectChange("fitnessGoal", value)}
                value={formData.fitnessGoal}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select fitness goal" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="loseWeight">Lose Weight</SelectItem>
                  <SelectItem value="gainMuscle">Gain Muscle</SelectItem>
                  <SelectItem value="stayFit">Stay Fit</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button type="submit" className="w-full bg-fitbuddy-primary hover:bg-fitbuddy-primary/90">
            Calculate My Plan
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default UserInputForm;
