
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Cell,
  Tooltip
} from "recharts";

interface MacroNutrients {
  protein: number;
  carbs: number;
  fats: number;
}

interface MicroNutrients {
  vitaminA: number;
  vitaminC: number;
  vitaminD: number;
  calcium: number;
  iron: number;
  omega3: number;
}

interface NutritionPlanProps {
  dailyCalories: number;
  macros: MacroNutrients;
  micronutrients: MicroNutrients;
  dietType: string;
}

const NutritionPlan = ({
  dailyCalories,
  macros,
  micronutrients,
  dietType
}: NutritionPlanProps) => {
  const { protein, carbs, fats } = macros;
  
  // Calculate percentages for visualization
  const totalGrams = protein + carbs + fats;
  const proteinPercent = Math.round((protein / totalGrams) * 100);
  const carbsPercent = Math.round((carbs / totalGrams) * 100);
  const fatsPercent = Math.round((fats / totalGrams) * 100);
  
  // Calculate calories from each macro
  const proteinCalories = protein * 4;
  const carbsCalories = carbs * 4;
  const fatsCalories = fats * 9;
  
  // Prepare data for chart
  const macroChartData = [
    { name: "Protein", value: protein, calories: proteinCalories, color: "#4263eb" },
    { name: "Carbs", value: carbs, calories: carbsCalories, color: "#20c997" },
    { name: "Fats", value: fats, calories: fatsCalories, color: "#fab005" },
  ];
  
  const microChartData = [
    { name: "Vit A (mcg)", value: micronutrients.vitaminA },
    { name: "Vit C (mg)", value: micronutrients.vitaminC },
    { name: "Vit D (mcg)", value: micronutrients.vitaminD },
    { name: "Calcium (mg)", value: micronutrients.calcium },
    { name: "Iron (mg)", value: micronutrients.iron * 30 }, // Scaling for visibility
    { name: "Omega-3 (g)", value: micronutrients.omega3 * 300 }, // Scaling for visibility
  ];
  
  // Function to generate diet suggestions based on macros and diet type
  const getDietSuggestions = () => {
    const highProteinFoods = dietType === "vegetarian"
      ? ["Lentils", "Chickpeas", "Tofu", "Greek yogurt", "Cottage cheese", "Almonds", "Quinoa", "Edamame"]
      : ["Chicken breast", "Turkey", "Fish", "Lean beef", "Eggs", "Greek yogurt", "Cottage cheese", "Whey protein"];
    
    const healthyFats = dietType === "vegetarian"
      ? ["Avocado", "Nuts", "Olive oil", "Coconut oil", "Flaxseeds", "Chia seeds"]
      : ["Avocado", "Nuts", "Olive oil", "Salmon", "Eggs", "Cheese"];
    
    const complexCarbs = ["Brown rice", "Quinoa", "Sweet potatoes", "Oats", "Whole grain bread", "Fruits", "Vegetables"];
    
    return {
      highProteinFoods,
      healthyFats,
      complexCarbs
    };
  };
  
  const dietSuggestions = getDietSuggestions();

  return (
    <div className="space-y-8">
      <Card className="results-card">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            Daily Nutrition Plan
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div className="mb-4 md:mb-0">
              <p className="text-lg font-medium text-gray-700 dark:text-gray-300">
                Daily Target: <span className="metric-value">{dailyCalories}</span> calories
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Optimized for your body and goals
              </p>
            </div>
            
            {/* Macro distribution visualization */}
            <div className="flex items-center space-x-2 text-sm">
              <span className="font-medium flex items-center">
                <div className="w-3 h-3 bg-[#4263eb] rounded-full mr-1"></div> {proteinPercent}% Protein
              </span>
              <span className="font-medium flex items-center">
                <div className="w-3 h-3 bg-[#20c997] rounded-full mr-1"></div> {carbsPercent}% Carbs
              </span>
              <span className="font-medium flex items-center">
                <div className="w-3 h-3 bg-[#fab005] rounded-full mr-1"></div> {fatsPercent}% Fats
              </span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Macronutrient chart */}
            <div>
              <h3 className="text-lg font-medium mb-4 text-fitbuddy-secondary dark:text-gray-200">Macronutrients (g)</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={macroChartData}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value, name, props) => [`${value}g (${props.payload.calories} cal)`, name]}
                    />
                    <Bar dataKey="value" fill="#8884d8">
                      {macroChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            {/* Micronutrient chart */}
            <div>
              <h3 className="text-lg font-medium mb-4 text-fitbuddy-secondary dark:text-gray-200">Micronutrients</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={microChartData}>
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#82ca9d" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Note: Iron and Omega-3 values are scaled for visibility
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card className="results-card">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            Recommended Food Sources
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-medium text-fitbuddy-primary mb-2">Protein Sources</h4>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                {dietSuggestions.highProteinFoods.map((food, index) => (
                  <li key={index}>{food}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-fitbuddy-primary mb-2">Healthy Fat Sources</h4>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                {dietSuggestions.healthyFats.map((food, index) => (
                  <li key={index}>{food}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-fitbuddy-primary mb-2">Complex Carb Sources</h4>
              <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 space-y-1">
                {dietSuggestions.complexCarbs.map((food, index) => (
                  <li key={index}>{food}</li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="mt-6 bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              <strong>Pro Tip:</strong> Distribute your meals throughout the day. Aim for 3-5 meals with a good balance of protein, healthy fats and complex carbs.
              Adjust portion sizes to meet your daily calorie target.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default NutritionPlan;
