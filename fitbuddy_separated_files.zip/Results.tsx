
import { Button } from "@/components/ui/button";
import HealthMetrics from "./HealthMetrics";
import NutritionPlan from "./NutritionPlan";
import ExercisePlan from "./ExercisePlan";
import AdPlaceholder from "./AdPlaceholder";
import { ArrowUp } from "lucide-react";
import { useState, useRef } from "react";

interface ResultsProps {
  healthData: {
    bmi: number;
    bmiCategory: string;
    bmr: number;
    dailyCalories: number;
    macros: {
      protein: number;
      carbs: number;
      fats: number;
    };
    micronutrients: {
      vitaminA: number;
      vitaminC: number;
      vitaminD: number;
      calcium: number;
      iron: number;
      omega3: number;
    };
  };
  userData: {
    fitnessGoal: string;
    bodyType: string;
    dietType: string;
  };
}

const Results = ({ healthData, userData }: ResultsProps) => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Handle scroll to top function
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Show scroll-to-top button when user scrolls down
  if (typeof window !== "undefined") {
    window.addEventListener("scroll", () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    });
  }

  return (
    <div ref={resultsRef} className="w-full max-w-4xl mx-auto">
      <div className="mb-6">
        <AdPlaceholder position="top" />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <HealthMetrics 
            bmi={healthData.bmi} 
            bmiCategory={healthData.bmiCategory}
            bmr={healthData.bmr}
            dailyCalories={healthData.dailyCalories}
          />
          
          <NutritionPlan 
            dailyCalories={healthData.dailyCalories}
            macros={healthData.macros}
            micronutrients={healthData.micronutrients}
            dietType={userData.dietType}
          />
          
          <ExercisePlan 
            fitnessGoal={userData.fitnessGoal}
            bodyType={userData.bodyType}
          />
          
          <div className="mt-6">
            <AdPlaceholder position="footer" />
          </div>
        </div>
        
        <div className="hidden lg:block">
          <div className="sticky top-8">
            <AdPlaceholder position="sidebar" />
          </div>
        </div>
      </div>
      
      {showScrollTop && (
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-8 right-8 rounded-full shadow-md"
          onClick={scrollToTop}
        >
          <ArrowUp className="h-5 w-5" />
          <span className="sr-only">Scroll to top</span>
        </Button>
      )}
    </div>
  );
};

export default Results;
