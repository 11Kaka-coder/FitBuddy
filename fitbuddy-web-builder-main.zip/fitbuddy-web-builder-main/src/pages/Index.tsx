import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import UserInputForm from "@/components/UserInputForm";
import Results from "@/components/Results";
import { calculateHealthData } from "@/utils/calculations";
import { Activity, Dumbbell, Heart } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface UserFormData {
  age: string;
  gender: string;
  height: string;
  weight: string;
  activityLevel: string;
  bodyType: string;
  dietType: string;
  fitnessGoal: string;
}

const Index = () => {
  const [healthData, setHealthData] = useState<any>(null);
  const [userData, setUserData] = useState<any>(null);

  const handleFormSubmit = (formData: UserFormData) => {
    const processedData = {
      age: parseInt(formData.age),
      gender: formData.gender,
      height: parseFloat(formData.height),
      weight: parseFloat(formData.weight),
      activityLevel: formData.activityLevel,
      bodyType: formData.bodyType,
      dietType: formData.dietType,
      fitnessGoal: formData.fitnessGoal,
    };
    
    const calculatedData = calculateHealthData(processedData);
    
    setHealthData(calculatedData);
    setUserData({
      fitnessGoal: formData.fitnessGoal,
      bodyType: formData.bodyType,
      dietType: formData.dietType,
    });
    
    setTimeout(() => {
      window.scrollTo({
        top: document.getElementById("results-section")?.offsetTop || 0,
        behavior: "smooth",
      });
    }, 100);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
      <Header />
      
      <main className="flex-grow">
        <section className="py-16 md:py-24 px-6 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-fitbuddy-primary/5 to-transparent dark:from-fitbuddy-primary/10" />
          
          <div className="container mx-auto text-center max-w-4xl relative">
            <h1 className="text-4xl md:text-6xl font-bold text-fitbuddy-secondary dark:text-white mb-6 leading-tight animate-fade-in">
              Your Personal Health & 
              <span className="bg-gradient-to-r from-fitbuddy-primary to-fitbuddy-accent bg-clip-text text-transparent"> Fitness Journey </span>
              Starts Here
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-12 leading-relaxed max-w-3xl mx-auto animate-fade-in">
              Get a scientifically backed diet plan, exercise recommendations, and health insights 
              tailored specifically to your body and goals.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <Card className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border-2 transition-all duration-300 hover:shadow-lg hover:scale-105 group">
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-4">
                    <div className="bg-gradient-to-br from-fitbuddy-primary/20 to-fitbuddy-accent/20 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                      <Activity className="h-8 w-8 text-fitbuddy-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-xl text-center bg-gradient-to-r from-fitbuddy-secondary to-fitbuddy-primary bg-clip-text text-transparent">
                    Body Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-center text-gray-600 dark:text-gray-300">
                  Calculate your BMI, BMR and daily calorie needs based on your body composition and activity level.
                </CardContent>
              </Card>
              
              <Card className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border-2 transition-all duration-300 hover:shadow-lg hover:scale-105 group">
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-4">
                    <div className="bg-gradient-to-br from-fitbuddy-primary/20 to-fitbuddy-accent/20 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                      <Heart className="h-8 w-8 text-fitbuddy-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-xl text-center bg-gradient-to-r from-fitbuddy-secondary to-fitbuddy-primary bg-clip-text text-transparent">
                    Diet Plan
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-center text-gray-600 dark:text-gray-300">
                  Receive a personalized nutrition plan with macro and micronutrient breakdowns to meet your health goals.
                </CardContent>
              </Card>
              
              <Card className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border-2 transition-all duration-300 hover:shadow-lg hover:scale-105 group">
                <CardHeader className="pb-2">
                  <div className="flex justify-center mb-4">
                    <div className="bg-gradient-to-br from-fitbuddy-primary/20 to-fitbuddy-accent/20 p-4 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                      <Dumbbell className="h-8 w-8 text-fitbuddy-primary" />
                    </div>
                  </div>
                  <CardTitle className="text-xl text-center bg-gradient-to-r from-fitbuddy-secondary to-fitbuddy-primary bg-clip-text text-transparent">
                    Exercise Plan
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-center text-gray-600 dark:text-gray-300">
                  Get exercise recommendations suited to your body type and fitness goals.
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl p-8 shadow-xl border-2 border-gray-100 dark:border-gray-700">
              <UserInputForm onSubmit={handleFormSubmit} />
            </div>
          </div>
        </section>
        
        {healthData && userData && (
          <section id="results-section" className="py-16 px-6 bg-gradient-to-b from-gray-50 to-white dark:from-gray-900 dark:to-gray-800">
            <div className="container mx-auto">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-fitbuddy-secondary via-fitbuddy-primary to-fitbuddy-accent bg-clip-text text-transparent mb-4">
                  Your Personalized Health & Fitness Plan
                </h2>
                <p className="text-lg text-gray-600 dark:text-gray-300">
                  Based on your profile and goals, we've created the following recommendations
                </p>
              </div>
              
              <Results healthData={healthData} userData={userData} />
            </div>
          </section>
        )}
        
        {!healthData && (
          <section className="py-20 px-6 bg-gradient-to-b from-white to-gray-50 dark:from-gray-800 dark:to-gray-900">
            <div className="container mx-auto max-w-4xl">
              <h2 className="text-3xl font-bold text-center bg-gradient-to-r from-fitbuddy-secondary to-fitbuddy-primary bg-clip-text text-transparent mb-12">
                Why Choose FitBuddy?
              </h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-fitbuddy-primary">Scientifically Backed</h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      Our calculations use proven formulas like the Mifflin-St Jeor Equation for BMR and follow
                      established nutritional guidelines for macronutrient and micronutrient recommendations.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-fitbuddy-primary">Personalized Approach</h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      We consider your unique body type, current weight, activity level, dietary preferences,
                      and fitness goals to create a plan that works specifically for you.
                    </p>
                  </div>
                </div>
                
                <div className="space-y-8">
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-fitbuddy-primary">Holistic Wellness</h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      We don't just focus on weight - our approach integrates nutrition, exercise, and 
                      mindfulness for overall wellbeing.
                    </p>
                  </div>
                  
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-fitbuddy-primary">Easy to Follow</h3>
                    <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                      Our recommendations are practical and designed to fit into your daily life,
                      with clear explanations and actionable steps you can implement right away.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
