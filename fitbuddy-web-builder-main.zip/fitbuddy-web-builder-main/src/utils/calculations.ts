
export interface HealthData {
  bmi: number;
  bmiCategory: string;
  bmr: number;
  dailyCalories: number;
  macros: {
    protein: number;
    carbs: number;
    fats: number;
  };
  micronutrients: {
    vitaminA: number;
    vitaminC: number;
    vitaminD: number;
    calcium: number;
    iron: number;
    omega3: number;
  };
}

export interface UserData {
  age: number;
  gender: string;
  height: number;
  weight: number;
  activityLevel: string;
  bodyType: string;
  dietType: string;
  fitnessGoal: string;
}

// Calculate BMI (Body Mass Index)
export const calculateBMI = (height: number, weight: number): number => {
  // Height in meters (convert from cm)
  const heightInMeters = height / 100;
  return parseFloat((weight / (heightInMeters * heightInMeters)).toFixed(1));
};

// Determine BMI category
export const getBMICategory = (bmi: number): string => {
  if (bmi < 18.5) return "Underweight";
  if (bmi < 25) return "Normal weight";
  if (bmi < 30) return "Overweight";
  if (bmi < 35) return "Obesity class I";
  if (bmi < 40) return "Obesity class II";
  return "Obesity class III";
};

// Calculate BMR (Basal Metabolic Rate) using Mifflin-St Jeor Equation
export const calculateBMR = (
  weight: number,
  height: number,
  age: number,
  gender: string
): number => {
  if (gender === "male") {
    return Math.round((10 * weight) + (6.25 * height) - (5 * age) + 5);
  } else {
    return Math.round((10 * weight) + (6.25 * height) - (5 * age) - 161);
  }
};

// Calculate daily calorie needs based on activity level
export const calculateDailyCalories = (
  bmr: number,
  activityLevel: string,
  fitnessGoal: string
): number => {
  // Activity level multipliers
  const activityMultipliers: { [key: string]: number } = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    veryActive: 1.9,
  };

  // Calculate maintenance calories
  const maintenanceCalories = Math.round(bmr * activityMultipliers[activityLevel]);
  
  // Adjust based on fitness goal
  switch (fitnessGoal) {
    case "loseWeight":
      return Math.round(maintenanceCalories * 0.85); // 15% deficit
    case "gainMuscle":
      return Math.round(maintenanceCalories * 1.1); // 10% surplus
    case "stayFit":
    default:
      return maintenanceCalories;
  }
};

// Calculate macronutrient distribution
export const calculateMacros = (
  dailyCalories: number,
  fitnessGoal: string,
  bodyType: string
) => {
  let proteinPercentage = 0;
  let fatPercentage = 0;
  let carbPercentage = 0;

  // Adjust macros based on fitness goal and body type
  if (fitnessGoal === "loseWeight") {
    proteinPercentage = bodyType === "endomorph" ? 0.35 : 0.3;
    fatPercentage = 0.3;
    carbPercentage = 1 - proteinPercentage - fatPercentage;
  } else if (fitnessGoal === "gainMuscle") {
    proteinPercentage = bodyType === "ectomorph" ? 0.3 : 0.25;
    fatPercentage = bodyType === "ectomorph" ? 0.25 : 0.25;
    carbPercentage = 1 - proteinPercentage - fatPercentage;
  } else { // stayFit
    proteinPercentage = 0.25;
    fatPercentage = 0.3;
    carbPercentage = 0.45;
  }

  // Calculate grams of each macronutrient
  // Protein: 4 calories per gram
  // Carbs: 4 calories per gram
  // Fat: 9 calories per gram
  const proteinGrams = Math.round((dailyCalories * proteinPercentage) / 4);
  const carbGrams = Math.round((dailyCalories * carbPercentage) / 4);
  const fatGrams = Math.round((dailyCalories * fatPercentage) / 9);

  return {
    protein: proteinGrams,
    carbs: carbGrams,
    fats: fatGrams,
  };
};

// Calculate micronutrient needs (simplified for this application)
export const calculateMicronutrients = (
  weight: number,
  gender: string,
  age: number,
  fitnessGoal: string
) => {
  const baseMultiplier = gender === "male" ? 1.0 : 0.9;
  const ageMultiplier = age > 50 ? 1.2 : 1.0;
  
  // These are simplified values and not medical advice
  return {
    vitaminA: Math.round(900 * baseMultiplier * ageMultiplier), // mcg
    vitaminC: Math.round(90 * baseMultiplier * (fitnessGoal === "gainMuscle" ? 1.2 : 1.0)), // mg
    vitaminD: Math.round(15 * ageMultiplier), // mcg
    calcium: Math.round(1000 * ageMultiplier), // mg
    iron: gender === "female" && age < 50 ? 18 : 8, // mg
    omega3: Math.round(1.6 * baseMultiplier * weight / 70), // g
  };
};

// Main function to compute all health data
export const calculateHealthData = (userData: UserData): HealthData => {
  const { age, gender, height, weight, activityLevel, bodyType, fitnessGoal } = userData;

  // Calculate BMI and category
  const bmi = calculateBMI(height, weight);
  const bmiCategory = getBMICategory(bmi);

  // Calculate BMR
  const bmr = calculateBMR(weight, height, age, gender);

  // Calculate daily calorie needs
  const dailyCalories = calculateDailyCalories(bmr, activityLevel, fitnessGoal);

  // Calculate macronutrient distribution
  const macros = calculateMacros(dailyCalories, fitnessGoal, bodyType);

  // Calculate micronutrient needs
  const micronutrients = calculateMicronutrients(weight, gender, age, fitnessGoal);

  return {
    bmi,
    bmiCategory,
    bmr,
    dailyCalories,
    macros,
    micronutrients,
  };
};
