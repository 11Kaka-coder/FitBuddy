
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ExercisePlanProps {
  fitnessGoal: string;
  bodyType: string;
}

const ExercisePlan = ({ fitnessGoal, bodyType }: ExercisePlanProps) => {
  // Generate workout recommendations based on fitness goal and body type
  const getWorkoutPlan = () => {
    if (fitnessGoal === "loseWeight") {
      return {
        cardio: [
          { name: "HIIT (High-Intensity Interval Training)", duration: "20-30 min", frequency: "3-4x/week" },
          { name: "Brisk Walking", duration: "30-45 min", frequency: "5-7x/week" },
          { name: "Cycling", duration: "30-45 min", frequency: "3-5x/week" },
          { name: "Swimming", duration: "30-45 min", frequency: "2-3x/week" },
        ],
        strength: [
          { name: "Circuit Training", sets: "3", reps: "15-20", notes: "Minimal rest between exercises" },
          { name: "Full-Body Workouts", sets: "3", reps: "12-15", notes: "Focus on compound movements" },
          { name: "Bodyweight Training", sets: "3", reps: "15-20", notes: "Great for home workouts" },
        ],
        flexibility: [
          { name: "Dynamic Stretching", duration: "5-10 min", frequency: "Before workouts" },
          { name: "Static Stretching", duration: "10-15 min", frequency: "After workouts" },
        ],
      };
    } else if (fitnessGoal === "gainMuscle") {
      let strengthPlan;
      
      if (bodyType === "ectomorph") {
        strengthPlan = [
          { name: "Heavy Compound Lifts", sets: "4-5", reps: "6-8", notes: "Focus on progressive overload" },
          { name: "Split Routines", sets: "4", reps: "8-12", notes: "Train each muscle group 2x/week" },
          { name: "Limited Cardio", duration: "15-20 min", frequency: "2x/week", notes: "To maintain heart health" },
        ];
      } else if (bodyType === "mesomorph") {
        strengthPlan = [
          { name: "Balanced Hypertrophy", sets: "4", reps: "8-12", notes: "Mix of compound and isolation" },
          { name: "Split or Full Body", sets: "3-4", reps: "8-12", notes: "Both work well for this body type" },
          { name: "Moderate Cardio", duration: "20-30 min", frequency: "2-3x/week" },
        ];
      } else { // endomorph
        strengthPlan = [
          { name: "Compound Movements", sets: "4", reps: "8-10", notes: "Focus on larger muscle groups" },
          { name: "Supersets/Circuits", sets: "3", reps: "10-12", notes: "Keep heart rate elevated" },
          { name: "Regular Cardio", duration: "25-30 min", frequency: "3-4x/week", notes: "For fat management" },
        ];
      }
      
      return {
        cardio: [
          { name: "Moderate Intensity Cardio", duration: "20-30 min", frequency: "2-3x/week" },
          { name: "Incline Walking", duration: "20-25 min", frequency: "2-3x/week" },
        ],
        strength: strengthPlan,
        flexibility: [
          { name: "Dynamic Stretching", duration: "5-10 min", frequency: "Before workouts" },
          { name: "Foam Rolling", duration: "10 min", frequency: "After workouts" },
          { name: "Yoga", duration: "20-30 min", frequency: "1-2x/week" },
        ],
      };
    } else { // stayFit
      return {
        cardio: [
          { name: "Moderate Intensity", duration: "30 min", frequency: "3-5x/week" },
          { name: "Walking", duration: "30-60 min", frequency: "Daily" },
          { name: "Recreational Sports", duration: "Varied", frequency: "1-3x/week" },
        ],
        strength: [
          { name: "Full Body Workouts", sets: "2-3", reps: "10-15", notes: "Focus on functional movements" },
          { name: "Bodyweight Exercises", sets: "2-3", reps: "10-15", notes: "Can be done anywhere" },
          { name: "Light-Moderate Weights", sets: "2-3", reps: "12-15", notes: "Maintain muscle tone" },
        ],
        flexibility: [
          { name: "Full Body Stretching", duration: "10-15 min", frequency: "Daily" },
          { name: "Yoga", duration: "30-45 min", frequency: "2-3x/week" },
        ],
      };
    }
  };
  
  const workoutPlan = getWorkoutPlan();
  
  // Get yoga recommendations based on fitness goal
  const getYogaRecommendations = () => {
    if (fitnessGoal === "loseWeight") {
      return [
        { name: "Surya Namaskar (Sun Salutation)", benefits: "Full body workout, increases metabolism", difficulty: "Beginner-Intermediate" },
        { name: "Virabhadrasana (Warrior Pose Series)", benefits: "Strengthens legs, improves balance", difficulty: "Beginner-Intermediate" },
        { name: "Kumbhakasana (Plank Pose)", benefits: "Core strengthening, improves posture", difficulty: "Beginner" },
        { name: "Adho Mukha Svanasana (Downward Dog)", benefits: "Full body stretch, strengthens arms", difficulty: "Beginner" },
      ];
    } else if (fitnessGoal === "gainMuscle") {
      return [
        { name: "Chaturanga Dandasana (Four-Limbed Staff Pose)", benefits: "Strengthens arms, shoulders and core", difficulty: "Intermediate" },
        { name: "Navasana (Boat Pose)", benefits: "Core strengthening", difficulty: "Intermediate" },
        { name: "Bakasana (Crow Pose)", benefits: "Arm and core strength, balance", difficulty: "Advanced" },
        { name: "Vrikshasana (Tree Pose)", benefits: "Improves balance, strengthens legs", difficulty: "Beginner" },
      ];
    } else { // stayFit
      return [
        { name: "Tadasana (Mountain Pose)", benefits: "Improves posture and balance", difficulty: "Beginner" },
        { name: "Balasana (Child's Pose)", benefits: "Relaxation, gentle stretch for back", difficulty: "Beginner" },
        { name: "Bhujangasana (Cobra Pose)", benefits: "Strengthens spine, opens chest", difficulty: "Beginner" },
        { name: "Shavasana (Corpse Pose)", benefits: "Deep relaxation, stress reduction", difficulty: "Beginner" },
      ];
    }
  };
  
  const yogaRecommendations = getYogaRecommendations();

  return (
    <div className="space-y-6">
      <Card className="results-card">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            Exercise Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="strength">
            <TabsList className="w-full grid grid-cols-3 mb-6">
              <TabsTrigger value="strength">Strength Training</TabsTrigger>
              <TabsTrigger value="cardio">Cardio</TabsTrigger>
              <TabsTrigger value="flexibility">Flexibility</TabsTrigger>
            </TabsList>
            
            <TabsContent value="strength" className="space-y-4">
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg mb-4">
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  <strong>Goal Focus:</strong> {fitnessGoal === "loseWeight" 
                    ? "Circuit training with shorter rest periods to maximize calorie burn" 
                    : fitnessGoal === "gainMuscle"
                      ? "Progressive overload with adequate rest between sets"
                      : "Functional movements and moderate resistance for overall fitness"}
                </p>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-gray-700">
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Exercise Type</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Sets</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Reps</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Notes</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workoutPlan.strength.map((exercise, index) => (
                      <tr key={index} className="border-t border-gray-200 dark:border-gray-700">
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.name}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.sets}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.reps}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.notes}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4">
                <h4 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Sample Exercises:</h4>
                <ul className="list-disc list-inside text-gray-700 dark:text-gray-300 grid grid-cols-1 md:grid-cols-2 gap-2">
                  <li>Squats (legs, core)</li>
                  <li>Bench Press / Push-ups (chest, triceps)</li>
                  <li>Deadlifts (back, legs, core)</li>
                  <li>Rows (back, biceps)</li>
                  <li>Shoulder Press (shoulders, triceps)</li>
                  <li>Lunges (legs, balance)</li>
                  <li>Pull-ups / Lat Pulldowns (back, biceps)</li>
                  <li>Planks (core stability)</li>
                </ul>
              </div>
            </TabsContent>
            
            <TabsContent value="cardio" className="space-y-4">
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg mb-4">
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  <strong>Goal Focus:</strong> {fitnessGoal === "loseWeight" 
                    ? "Higher intensity with intervals to maximize calorie burn" 
                    : fitnessGoal === "gainMuscle"
                      ? "Moderate cardio to support recovery without hindering muscle growth"
                      : "Consistent moderate cardio for heart health and endurance"}
                </p>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-gray-700">
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Type</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Duration</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Frequency</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workoutPlan.cardio.map((exercise, index) => (
                      <tr key={index} className="border-t border-gray-200 dark:border-gray-700">
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.name}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.duration}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.frequency}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4">
                <h4 className="font-semibold text-gray-700 dark:text-gray-300">Heart Rate Zones:</h4>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  For maximum fat burning, aim to keep your heart rate between 60-70% of your maximum heart rate
                  (220 minus your age). For cardiovascular improvement, 70-80% is ideal.
                </p>
              </div>
            </TabsContent>
            
            <TabsContent value="flexibility" className="space-y-4">
              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg mb-4">
                <p className="text-sm text-gray-700 dark:text-gray-300">
                  <strong>Benefits:</strong> Improved range of motion, reduced injury risk, better posture,
                  reduced muscle tension and enhanced recovery.
                </p>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="bg-gray-100 dark:bg-gray-700">
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Type</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">Duration</th>
                      <th className="p-3 text-left text-gray-700 dark:text-gray-300">When To Do It</th>
                    </tr>
                  </thead>
                  <tbody>
                    {workoutPlan.flexibility.map((exercise, index) => (
                      <tr key={index} className="border-t border-gray-200 dark:border-gray-700">
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.name}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.duration}</td>
                        <td className="p-3 text-gray-800 dark:text-gray-200">{exercise.frequency}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      <Card className="results-card">
        <CardHeader>
          <CardTitle className="text-xl font-semibold text-fitbuddy-secondary dark:text-white">
            Recommended Yoga Practices
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {yogaRecommendations.map((yoga, index) => (
              <div 
                key={index} 
                className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg border border-gray-100 dark:border-gray-700"
              >
                <h4 className="font-medium text-fitbuddy-primary mb-1">{yoga.name}</h4>
                <p className="text-sm text-gray-700 dark:text-gray-300 mb-1">
                  <span className="font-medium">Benefits:</span> {yoga.benefits}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  <span className="font-medium">Difficulty:</span> {yoga.difficulty}
                </p>
              </div>
            ))}
          </div>
          
          <div className="mt-6 bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              <strong>Tip:</strong> Start with 10-15 minutes of yoga daily and gradually increase duration.
              Focus on proper form rather than pushing too hard too quickly.
              Consider taking a class with a certified instructor for correct technique.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ExercisePlan;
