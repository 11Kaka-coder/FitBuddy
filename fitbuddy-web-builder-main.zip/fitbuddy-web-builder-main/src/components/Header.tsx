
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Moon, Sun } from "lucide-react";

const Header = () => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    setIsDarkMode(prefersDark);
    
    if (prefersDark) {
      document.documentElement.classList.add("dark");
    }
  }, []);

  const toggleDarkMode = () => {
    const newMode = !isDarkMode;
    setIsDarkMode(newMode);
    
    if (newMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  };

  return (
    <header className="w-full bg-gradient-to-r from-white via-gray-50 to-white dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 shadow-lg backdrop-blur-sm py-4 px-6 md:px-8 sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <div className="h-12 w-12 bg-gradient-to-br from-fitbuddy-primary to-fitbuddy-accent rounded-xl flex items-center justify-center shadow-lg transform transition-all duration-300 hover:scale-105">
            <span className="text-white font-bold text-2xl">F</span>
          </div>
          <h1 className="text-3xl font-bold ml-4 text-fitbuddy-secondary dark:text-white bg-gradient-to-r from-fitbuddy-secondary via-fitbuddy-primary to-fitbuddy-accent bg-clip-text text-transparent">
            Fit<span className="text-fitbuddy-primary">Buddy</span>
          </h1>
        </div>
        
        <Button 
          variant="outline" 
          size="icon" 
          onClick={toggleDarkMode} 
          className="ml-4 rounded-xl shadow-md hover:shadow-lg transition-all duration-300"
        >
          {isDarkMode ? (
            <Sun className="h-5 w-5 text-yellow-500" />
          ) : (
            <Moon className="h-5 w-5 text-blue-600" />
          )}
          <span className="sr-only">Toggle dark mode</span>
        </Button>
      </div>
    </header>
  );
};

export default Header;
